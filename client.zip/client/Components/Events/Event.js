/* eslint-disable no-unused-vars */
import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
} from 'react-native';
import eventsData from './eventsData.js';


class Event extends Component {


  render() {
    return ( 
      <ScrollView>
       
      </ScrollView>
    );
  }
}

export default Event;

const styles = StyleSheet.create({

});
