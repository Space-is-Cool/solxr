import React from 'react';
import { View, Text } from 'react-native';

const CommunityScreen = ({navigation, route}) => {
  return (
    <View>
      <Text>Community Screen</Text>
    </View>
  );
};

export default CommunityScreen;
