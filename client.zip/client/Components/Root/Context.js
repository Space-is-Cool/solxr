import {createContext} from 'react';


export const IotdContext = createContext('');
export const FontContext = createContext({});
export const MusicContext = createContext('');
export const SoundOneContext = createContext('');
